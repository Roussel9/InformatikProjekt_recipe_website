package com.example.starter;



import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.http.Cookie;
import io.vertx.core.http.CookieSameSite;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.auth.JWTOptions;
import io.vertx.ext.auth.jdbc.JDBCAuth;
import io.vertx.ext.auth.jwt.JWTAuth;
import io.vertx.ext.jdbc.JDBCClient;
import io.vertx.ext.web.RoutingContext;
import io.vertx.sqlclient.Tuple;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class AuthService {
  private final Vertx vertx;
  private final JDBCClient dbClient;
  private final JDBCAuth authProvider;

  private String activeSessionId = UUID.randomUUID().toString();
  private int failedAttempts = 0;

  public AuthService(Vertx vertx, JDBCClient dbClient) {
    this.vertx = vertx;
    this.dbClient = dbClient;
    this.authProvider = JDBCAuth.create(vertx, dbClient);
  }


  public String hashPassword(String password) {
    return authProvider.computeHash(password, null);
  }


  public void registerUser(RoutingContext context) {
    String name = context.request().getFormAttribute("name");
    String email = context.request().getFormAttribute("email");
    String password = context.request().getFormAttribute("password");

    if (name == null || email == null || password == null) {
      context.response().setStatusCode(400).end("⚠ Alle Felder sind erforderlich!");
      return;
    }

    String hashedPassword = authProvider.computeHash(password, null);
    String query = "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)";

    dbClient.updateWithParams(query, new JsonArray().add(name).add(email).add(hashedPassword), res -> {
      if (res.succeeded()) {
        context.response()
                .setStatusCode(303)
                .putHeader("Location", "/login.html") // Umleitung zur Login-Seite nach Registrierung
                .end();
        System.out.println("okay");

      } else {
        System.out.println("nicht gut ");

        context.response().setStatusCode(500).end("❌ Fehler bei Registrierung");
      }
    });
  }


  public void loginUser(RoutingContext context, JWTAuth jwtAuth) {
    String email = context.request().getFormAttribute("email");
    String password = context.request().getFormAttribute("password");

    if (email == null || password == null) {
      context.response().setStatusCode(400).end("⚠ Email und Passwort sind erforderlich!");
      return;
    }

    String query = "SELECT id, password_hash FROM users WHERE email = ?";

    dbClient.queryWithParams(query, new JsonArray().add(email), res -> {
      if (res.failed()) {
        context.response().setStatusCode(500).end("❌ Datenbankfehler!");
        return;
      }

      if (res.result().getRows().isEmpty()) {
        context.response().setStatusCode(404).end("❌ Benutzer nicht gefunden!");
        return;
      }

      JsonObject user = res.result().getRows().get(0);
      int userId = user.getInteger("id");
      String storedHash = user.getString("password_hash");

      if (authProvider.computeHash(password, null).equals(storedHash)) {
        failedAttempts = 0; // Erfolgreicher Login -> Zurücksetzen der fehlgeschlagenen Versuche

        // Neue Session-ID generieren
        String newSessionId = UUID.randomUUID().toString();

        // Session in die Datenbank speichern
        String insertSessionQuery = "INSERT INTO sessions (session_id, user_id) VALUES (?, ?)";

        dbClient.updateWithParams(insertSessionQuery, new JsonArray().add(newSessionId).add(userId), sessionRes -> {
          if (sessionRes.succeeded()) {
            // Session-Cookie setzen
            context.addCookie(Cookie.cookie("session-id", newSessionId)
              .setHttpOnly(true)
              .setSameSite(CookieSameSite.LAX));


            // Weiterleitung zur Startseite
            context.response()
              .setStatusCode(303)
              .putHeader("Location", "/homePage.html")
              .end();
          } else {
            context.response().setStatusCode(500).end("❌ Fehler beim Speichern der Session!");
          }
        });
      } else {
        failedAttempts++;
        context.response().setStatusCode(401).end("❌ Falsches Passwort!");
      }
    });
  }



  public void getUserIdFromSession(RoutingContext context, Handler<AsyncResult<Integer>> resultHandler) {
    String sessionId = context.getCookie("session-id") != null ? context.getCookie("session-id").getValue() : null;

    if (sessionId == null) {
      resultHandler.handle(Future.succeededFuture(-1));
      return;
    }

    String query = "SELECT user_id FROM sessions WHERE session_id = ?";

    dbClient.queryWithParams(query, new JsonArray().add(sessionId), res -> {
      if (res.failed() || res.result().getRows().isEmpty()) {
        resultHandler.handle(Future.succeededFuture(-1));
      } else {
        int userId = res.result().getRows().get(0).getInteger("user_id");
        resultHandler.handle(Future.succeededFuture(userId));
      }
    });
  }


  public void getProfile(RoutingContext context) {
    getUserIdFromSession(context, userIdResult -> {
      if (userIdResult.failed() || userIdResult.result() == -1) {
        context.response().setStatusCode(401).end("⚠ Nicht autorisiert! Bitte einloggen.");
        return;
      }

      int userId = userIdResult.result();
      String query = "SELECT title, description, portions, image_url FROM recipes WHERE user_id = ?";
      //String query = "INSERT INTO recipes (user_id, , created_at) VALUES (?, ?, ?, ?, ?, NOW())";

      dbClient.queryWithParams(query, new JsonArray().add(userId), res -> {
        if (res.succeeded()) {
          JsonArray recipes = new JsonArray(res.result().getRows());
          context.response().putHeader("Content-Type", "application/json").end(recipes.encode());
        } else {
          context.response().setStatusCode(500).end("❌ Fehler beim Abrufen der Rezepte");
        }
      });
    });
  }


  public void addRecipe(RoutingContext context) {
    getUserIdFromSession(context, userIdResult -> {
      if (userIdResult.failed() || userIdResult.result() == -1) {
        context.response().setStatusCode(401).end("⚠ Nicht autorisiert! Bitte einloggen.");
        return;
      }

      int userId = userIdResult.result();

      // 📌 Formulardaten auslesen
      String title = context.request().getFormAttribute("title");
      String description = context.request().getFormAttribute("description");
      String portionsStr = context.request().getFormAttribute("portions");
      String imageUrl = context.request().getFormAttribute("image_url");

      // Standardwerte setzen, falls leer
      int portions = (portionsStr != null) ? Integer.parseInt(portionsStr) : 1;
      if (imageUrl == null || imageUrl.isEmpty()) imageUrl = "default.png";

      if (title == null || description == null) {
        context.response().setStatusCode(400).end("⚠ Alle Felder sind erforderlich!");
        return;
      }

      // 📌 Rezept speichern
      String recipeQuery = "INSERT INTO recipes (user_id, title, description, portions, image_url, created_at) VALUES (?, ?, ?, ?, ?, NOW())";

      dbClient.updateWithParams(recipeQuery, new JsonArray().add(userId).add(title).add(description).add(portions).add(imageUrl), res -> {
        if (res.succeeded()) {
          int recipeId = res.result().getKeys().getInteger(0); // ID des neuen Rezepts holen

          // 📌 Zutaten speichern
          saveIngredients(recipeId, context);

          context.response()
            .setStatusCode(303)
            .putHeader("Location", "/profil.html") // Weiterleitung zur Profilseite
            .end();
        } else {
          res.cause().printStackTrace();
          context.response().setStatusCode(500).end("❌ Fehler beim Speichern des Rezepts!");
        }
      });
    });
  }

  private void saveIngredients(int recipeId, RoutingContext context) {
    int ingredientIndex = 1;

    while (true) {
      String name = context.request().getFormAttribute("ingredient_" + ingredientIndex + "_name");
      String amountStr = context.request().getFormAttribute("ingredient_" + ingredientIndex + "_amount");
      String unit = context.request().getFormAttribute("ingredient_" + ingredientIndex + "_unit");

      if (name == null) break; // Keine weiteren Zutaten

      double amount = (amountStr != null) ? Double.parseDouble(amountStr) : 0.0;

      // 1️⃣ Hol die Ingredient ID oder füge die Zutat neu ein
      String getOrCreateIngredientQuery =
        "INSERT INTO ingredients (name) SELECT ? WHERE NOT EXISTS (SELECT 1 FROM ingredients WHERE name = ?)";

      dbClient.updateWithParams(getOrCreateIngredientQuery, new JsonArray().add(name).add(name), res -> {
        if (res.failed()) {
          res.cause().printStackTrace();
          return;
        }

        // 2️⃣ Danach Ingredient ID holen und Rezept speichern
        String ingredientQuery =
          "INSERT INTO recipe_ingredients (recipe_id, ingredient_id, amount, unit) " +
            "VALUES (?, (SELECT id FROM ingredients WHERE name = ? LIMIT 1), ?, ?)";

        JsonArray params = new JsonArray()
          .add(recipeId)
          .add(name)
          .add(amount)
          .add(unit);

        dbClient.updateWithParams(ingredientQuery, params, res2 -> {
          if (res2.succeeded()) {
            System.out.println("✅ Zutat gespeichert: " + name);
          } else {
            res2.cause().printStackTrace();
          }
        });
      });

      ingredientIndex++;
    }
  }



  public void logoutUser(RoutingContext context) {
    Cookie authCookie = context.getCookie("session-id");

    if (authCookie == null) {
      // Kein Token vorhanden, daher kein Logout nötig
      context.response().setStatusCode(401).end("❌ Kein aktiver Login gefunden.");
      return;
    }

    // Lösche das Authentifizierungs-Cookie
    context.response().addCookie(Cookie.cookie("session-id", "")
      .setHttpOnly(true)
      .setSecure(false)  // Falls du HTTPS nutzt, setze `true`
      .setSameSite(CookieSameSite.LAX)
      .setPath("/")
      .setMaxAge(0)); // Sofort löschen

    // Setze die Session-ID zurück
    activeSessionId = UUID.randomUUID().toString();

    // Weiterleitung zur Login-Seite nach dem Logout
    context.response().setStatusCode(303)
      .putHeader("Location", "/login.html")
      .end("erfolgreich ausgeloggt");
  }


}



