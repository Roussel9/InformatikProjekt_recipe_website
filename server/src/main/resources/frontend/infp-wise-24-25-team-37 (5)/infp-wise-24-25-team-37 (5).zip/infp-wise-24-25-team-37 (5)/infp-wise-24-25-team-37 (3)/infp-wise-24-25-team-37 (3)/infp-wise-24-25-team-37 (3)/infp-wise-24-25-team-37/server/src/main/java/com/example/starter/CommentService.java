package com.example.starter;

import io.vertx.core.Vertx;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.jdbc.JDBCClient;
import io.vertx.ext.web.RoutingContext;

public class CommentService {
  private final JDBCClient dbClient;

  public CommentService(Vertx vertx, JDBCClient dbClient) {
    this.dbClient = dbClient;
  }

  // 🔹 1️⃣ Kommentar erstellen
  public void createComment(RoutingContext context) {
    if (context.user() == null) {
      context.response().setStatusCode(401).end("❌ Benutzer nicht authentifiziert!");
      return;
    }

    String tokenUserId = context.user().principal().getString("userId");
    String recipeId = context.pathParam("recipe_id");

    JsonObject body = context.getBodyAsJson();
    String content = body.getString("content");

    if (content == null || content.trim().isEmpty()) {
      context.response().setStatusCode(400).end("⚠ Kommentar darf nicht leer sein!");
      return;
    }

    String query = "INSERT INTO comments (user_id, recipe_id, content) VALUES (?, ?, ?)";
    JsonArray params = new JsonArray().add(tokenUserId).add(recipeId).add(content);

    dbClient.updateWithParams(query, params, res -> {
      if (res.succeeded()) {
        // 🔍 ID des neuen Kommentars abrufen
        Number commentId = res.result().getKeys().getInteger(0);

        JsonObject response = new JsonObject()
          .put("message", "✅ Kommentar erfolgreich erstellt!")
          .put("comment_id", commentId);

        context.response().setStatusCode(201)
          .putHeader("Content-Type", "application/json")
          .end(response.encode());
      } else {
        context.response().setStatusCode(500).end("❌ Fehler: " + res.cause().getMessage());
      }
    });
  }


  // 🔹 2️⃣ Alle Kommentare zu einem Rezept abrufen (Nutzer muss eingeloggt sein)
  public void getCommentsByRecipeId(RoutingContext context) {
    if (context.user() == null) {
      context.response().setStatusCode(401).end("❌ Benutzer nicht authentifiziert!");
      return;
    }

    String tokenUserId = context.user().principal().getString("userId");
    System.out.println("🔐 Authentifizierter Nutzer: " + tokenUserId);

    String recipeId = context.pathParam("recipe_id");

    // 🔍 Alle Kommentare für das Rezept abrufen (nicht nur die vom eingeloggten Nutzer)
    String query = "SELECT c.id, c.content, c.user_id FROM comments c " +
      "WHERE c.recipe_id = ?";
    JsonArray params = new JsonArray().add(recipeId);

    dbClient.queryWithParams(query, params, res -> {
      if (res.succeeded()) {
        context.response().setStatusCode(200)
          .putHeader("Content-Type", "application/json")
          .end(new JsonObject().put("comments", res.result().getRows()).encode());
      } else {
        context.response().setStatusCode(500).end("❌ Fehler: " + res.cause().getMessage());
      }
    });
  }


  // 🔹 3️⃣ Einen bestimmten Kommentar abrufen (nur, wenn er vom eingeloggten Nutzer stammt)
  public void getCommentById(RoutingContext context) {
    if (context.user() == null) {
      context.response().setStatusCode(401).end("❌ Benutzer nicht authentifiziert!");
      return;
    }

    String tokenUserId = context.user().principal().getString("userId");
    System.out.println("🔐 Authentifizierter Nutzer: " + tokenUserId);

    String commentId = context.pathParam("comment_id");
    String recipeId = context.pathParam("recipe_id");

    // 🔍 Kommentar für das Rezept anhand der Kommentar-ID und der Rezept-ID abrufen
    String query = "SELECT c.id, c.content, c.user_id FROM comments c " +
      "WHERE c.id = ? AND c.recipe_id = ?";
    JsonArray params = new JsonArray().add(commentId).add(recipeId);

    dbClient.queryWithParams(query, params, res -> {
      if (res.succeeded() && !res.result().getRows().isEmpty()) {
        context.response().setStatusCode(200)
          .putHeader("Content-Type", "application/json")
          .end(new JsonObject().put("comment", res.result().getRows().get(0)).encode());
      } else {
        context.response().setStatusCode(404).end("❌ Kommentar nicht gefunden oder nicht dein eigener!");
      }
    });
  }


  // 🔹 4️⃣ Kommentar aktualisieren (nur eigene)
  public void updateComment(RoutingContext context) {
    if (context.user() == null) {
      context.response().setStatusCode(401).end("❌ Benutzer nicht authentifiziert!");
      return;
    }

    // Benutzer-ID aus dem Token extrahieren
    String tokenUserId = context.user().principal().getString("userId");

    // Rezept-ID aus der URL holen
    String recipeId = context.pathParam("recipe_id");

    // Neues Kommentar-Content aus dem Request-Body holen
    JsonObject body = context.getBodyAsJson();
    String newContent = body.getString("content");

    // Überprüfen, ob der neue Kommentarinhalt gültig ist
    if (newContent == null || newContent.trim().isEmpty()) {
      context.response().setStatusCode(400).end("⚠ Neuer Kommentar darf nicht leer sein!");
      return;
    }

    // 🔍 Überprüfen, ob der Kommentar des Nutzers für das Rezept existiert
    String checkQuery = "SELECT id FROM comments WHERE user_id = ? AND recipe_id = ? LIMIT 1";
    JsonArray checkParams = new JsonArray().add(tokenUserId).add(recipeId);

    dbClient.queryWithParams(checkQuery, checkParams, checkRes -> {
      if (checkRes.succeeded() && !checkRes.result().getRows().isEmpty()) {
        // Kommentar existiert → ID des Kommentars erhalten
        String commentId = checkRes.result().getRows().get(0).getString("id");

        // Kommentar aktualisieren
        String updateQuery = "UPDATE comments SET content = ? WHERE id = ?";
        JsonArray updateParams = new JsonArray().add(newContent).add(commentId);

        dbClient.updateWithParams(updateQuery, updateParams, updateRes -> {
          if (updateRes.succeeded()) {
            context.response().setStatusCode(200).end("✅ Kommentar erfolgreich aktualisiert!");
          } else {
            context.response().setStatusCode(500).end("❌ Fehler: " + updateRes.cause().getMessage());
          }
        });
      } else {
        context.response().setStatusCode(404).end("❌ Kommentar nicht gefunden oder nicht dein eigener Kommentar!");
      }
    });
  }


  // 🔹 5️⃣ Kommentar löschen (nur eigene)
  public void deleteComment(RoutingContext context) {
    if (context.user() == null) {
      context.response().setStatusCode(401).end("❌ Benutzer nicht authentifiziert!");
      return;
    }

    // Benutzer-ID aus dem Token extrahieren
    String tokenUserId = context.user().principal().getString("userId");

    // Rezept-ID aus der URL holen
    String recipeId = context.pathParam("recipe_id");

    // 🔍 Überprüfen, ob der Kommentar des Nutzers für das Rezept existiert
    String checkQuery = "SELECT id FROM comments WHERE user_id = ? AND recipe_id = ? LIMIT 1";
    JsonArray checkParams = new JsonArray().add(tokenUserId).add(recipeId);

    dbClient.queryWithParams(checkQuery, checkParams, checkRes -> {
      if (checkRes.succeeded() && !checkRes.result().getRows().isEmpty()) {
        // Kommentar existiert → ID des Kommentars erhalten
        String commentId = checkRes.result().getRows().get(0).getString("id");

        // Kommentar löschen
        String deleteQuery = "DELETE FROM comments WHERE id = ?";
        JsonArray deleteParams = new JsonArray().add(commentId);

        dbClient.updateWithParams(deleteQuery, deleteParams, deleteRes -> {
          if (deleteRes.succeeded()) {
            context.response().setStatusCode(200).end("✅ Kommentar erfolgreich gelöscht!");
          } else {
            context.response().setStatusCode(500).end("❌ Fehler: " + deleteRes.cause().getMessage());
          }
        });
      } else {
        context.response().setStatusCode(404).end("❌ Kommentar nicht gefunden oder nicht dein eigener Kommentar!");
      }
    });
  }

}



