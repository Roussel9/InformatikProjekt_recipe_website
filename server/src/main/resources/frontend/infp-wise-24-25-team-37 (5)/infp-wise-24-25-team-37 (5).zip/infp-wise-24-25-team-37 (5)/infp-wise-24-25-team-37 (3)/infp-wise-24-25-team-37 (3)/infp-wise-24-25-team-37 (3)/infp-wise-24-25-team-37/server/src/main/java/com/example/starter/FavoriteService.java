package com.example.starter;

import io.vertx.core.Vertx;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.jdbc.JDBCClient;
import io.vertx.ext.web.RoutingContext;

import java.util.List;

public class FavoriteService {
  private final JDBCClient dbClient;

  public FavoriteService(Vertx vertx, JDBCClient dbClient) {
    this.dbClient = dbClient;
  }

  // 1. Favorit erstellen (Rezept zu Favoriten hinzufügen)
 /* public void addFavorite(RoutingContext context) {
    // 🔐 Prüfen, ob der Benutzer eingeloggt ist
    if (context.user() == null) {
      context.response().setStatusCode(401).end("❌ Benutzer nicht authentifiziert!");
      return;
    }

    // 🔍 ID des eingeloggten Nutzers aus dem Token holen
    String tokenUserId = context.user().principal().getString("userId");
    if (tokenUserId == null) {
      context.response().setStatusCode(401).end("❌ Kein Benutzer im Token gefunden!");
      return;
    }

    // 📌 Rezept-ID aus der URL holen
    String recipeId = context.pathParam("recipe_id");
    if (recipeId == null) {
      context.response().setStatusCode(400).end("⚠ Rezept-ID ist erforderlich!");
      return;
    }

    // ✅ Prüfen, ob das Rezept existiert
    String checkRecipeQuery = "SELECT id FROM recipes WHERE id = ?";
    JsonArray recipeParams = new JsonArray().add(recipeId);

    dbClient.queryWithParams(checkRecipeQuery, recipeParams, recipeRes -> {
      if (recipeRes.succeeded() && !recipeRes.result().getRows().isEmpty()) {

        // ✅ Prüfen, ob das Rezept bereits in den Favoriten ist
        String checkFavoriteQuery = "SELECT 1 FROM favorites WHERE user_id = ? AND recipe_id = ?";
        JsonArray checkFavoriteParams = new JsonArray().add(tokenUserId).add(recipeId);

        dbClient.queryWithParams(checkFavoriteQuery, checkFavoriteParams, checkRes -> {
          if (checkRes.succeeded() && !checkRes.result().getRows().isEmpty()) {
            context.response().setStatusCode(409).end("⚠ Dieses Rezept ist bereits in deinen Favoriten!");
          } else {
            // ✅ Rezept zu den Favoriten des eingeloggten Nutzers hinzufügen
            String insertQuery = "INSERT INTO favorites (user_id, recipe_id) VALUES (?, ?)";
            JsonArray insertParams = new JsonArray().add(tokenUserId).add(recipeId);

            dbClient.updateWithParams(insertQuery, insertParams, insertRes -> {
              if (insertRes.succeeded()) {
                context.response()
                  .setStatusCode(201)
                  .putHeader("Content-Type", "application/json")
                  .end(new JsonObject().put("message", "✅ Rezept erfolgreich zu deinen Favoriten hinzugefügt!").encode());
              } else {
                context.response().setStatusCode(500).end("❌ Fehler beim Hinzufügen des Favoriten: " + insertRes.cause().getMessage());
              }
            });
          }
        });

      } else {
        context.response().setStatusCode(404).end("❌ Rezept nicht gefunden!");
      }
    });
  }*/

  /*public void addToFavorites(RoutingContext context) {
    if (context.user() == null) {
      context.response().setStatusCode(401).end("❌ Benutzer nicht authentifiziert!");
      return;
    }

    String tokenUserId = context.user().principal().getString("userId");
    String recipeId = context.pathParam("recipe_id");

    if (recipeId == null) {
      context.response().setStatusCode(400).end("⚠ Rezept-ID ist erforderlich!");
      return;
    }

    String insertQuery = "INSERT INTO favorites (user_id, recipe_id) VALUES (?, ?)";
    JsonArray params = new JsonArray().add(tokenUserId).add(recipeId);

    dbClient.updateWithParams(insertQuery, params, res -> {
      if (res.succeeded()) {
        context.response().setStatusCode(201).end("✅ Rezept zu Favoriten hinzugefügt!");
      } else {
        context.response().setStatusCode(500).end("❌ Fehler beim Hinzufügen zu Favoriten: " + res.cause().getMessage());
      }
    });
  }*/




  // 2. eine seiner bestimmte Favorite abrufen

  public void getUserFavoriteByRecipeId(RoutingContext context) {
    // 🔐 Prüfen, ob der Benutzer eingeloggt ist
    if (context.user() == null) {
      context.response().setStatusCode(401).end("❌ Benutzer nicht authentifiziert!");
      return;
    }

    // 🔍 ID des eingeloggten Nutzers aus dem Token holen
    String tokenUserId = context.user().principal().getString("userId");
    if (tokenUserId == null) {
      context.response().setStatusCode(401).end("❌ Kein Benutzer im Token gefunden!");
      return;
    }

    // 📌 Rezept-ID aus der URL holen
    String recipeId = context.pathParam("recipe_id");
    if (recipeId == null) {
      context.response().setStatusCode(400).end("⚠ Rezept-ID ist erforderlich!");
      return;
    }

    // 📊 SQL-Query, um das Rezept zu finden, das zu den Favoriten des eingeloggten Benutzers gehört
    String query = "SELECT r.id, r.title, r.description " +
      "FROM favorites f " +
      "JOIN recipes r ON f.recipe_id = r.id " +
      "WHERE f.user_id = ? AND f.recipe_id = ?";
    JsonArray params = new JsonArray().add(tokenUserId).add(recipeId);

    dbClient.queryWithParams(query, params, res -> {
      if (res.succeeded()) {
        // Wenn keine Favoriten gefunden wurden
        if (res.result().getRows().isEmpty()) {
          context.response().setStatusCode(404).end("❌ Dieses Rezept ist nicht in deinen Favoriten!");
        } else {
          // Rezeptdetails zurückgeben
          context.response()
            .setStatusCode(200)
            .putHeader("Content-Type", "application/json")
            .end(new JsonObject().put("favorite_recipe", res.result().getRows().get(0)).encode());
        }
      } else {
        context.response().setStatusCode(500).end("❌ Fehler beim Abrufen des Rezepts: " + res.cause().getMessage());
      }
    });
  }



  // 3. Favorit löschen (Rezept aus den Favoriten entfernen)
  public void deleteFavorite(RoutingContext context) {
    // 🔐 Prüfen, ob der Benutzer eingeloggt ist
    if (context.user() == null) {
      context.response().setStatusCode(401).end("❌ Benutzer nicht authentifiziert!");
      return;
    }

    // 🔍 ID des eingeloggten Nutzers aus dem Token holen
    String tokenUserId = context.user().principal().getString("userId");
    if (tokenUserId == null) {
      context.response().setStatusCode(401).end("❌ Kein Benutzer im Token gefunden!");
      return;
    }

    // 📌 Rezept-ID aus der URL holen
    String recipeId = context.pathParam("recipe_id");
    if (recipeId == null) {
      context.response().setStatusCode(400).end("⚠ Rezept-ID ist erforderlich!");
      return;
    }

    // 📊 SQL-Query, um das Rezept zu finden, das der eingeloggte Benutzer in seinen Favoriten hat
    String query = "SELECT 1 FROM favorites WHERE user_id = ? AND recipe_id = ?";
    JsonArray params = new JsonArray().add(tokenUserId).add(recipeId);

    dbClient.queryWithParams(query, params, res -> {
      if (res.succeeded() && !res.result().getRows().isEmpty()) {
        // Rezept ist in den Favoriten des Benutzers, nun löschen
        String deleteQuery = "DELETE FROM favorites WHERE user_id = ? AND recipe_id = ?";
        dbClient.updateWithParams(deleteQuery, params, deleteRes -> {
          if (deleteRes.succeeded()) {
            context.response()
              .setStatusCode(200)
              .putHeader("Content-Type", "application/json")
              .end(new JsonObject().put("message", "✅ Rezept erfolgreich aus deinen Favoriten entfernt!").encode());
          } else {
            context.response().setStatusCode(500).end("❌ Fehler beim Löschen des Favoriten: " + deleteRes.cause().getMessage());
          }
        });
      } else {
        context.response().setStatusCode(404).end("❌ Rezept ist nicht in deinen Favoriten!");
      }
    });
  }



}

