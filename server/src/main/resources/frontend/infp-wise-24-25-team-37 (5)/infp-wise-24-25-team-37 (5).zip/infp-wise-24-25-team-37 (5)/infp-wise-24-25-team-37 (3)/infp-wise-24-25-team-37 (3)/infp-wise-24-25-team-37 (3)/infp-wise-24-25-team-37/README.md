##  Technologie-Stack für unser Projekt

###  Backend
- **Vert.x** – High-Performance Web-Framework für Java
- **MariaDB** – SQL-Datenbank für Rezepte, Nutzer und Kommentare
- **apiDoc** –  Dokumentation des Backends

###  Frontend
- **HTML & CSS** – UI-Design und Struktur der Webanwendung
- **Bootstrap** – Für schnellere und responsive Styles

###  DevOps & Versionierung
- **GitLab** – Repository für Zusammenarbeit und CI/CD


